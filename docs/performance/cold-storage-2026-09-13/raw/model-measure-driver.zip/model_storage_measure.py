"""Measure host process restart and first inference separately; no cache clearing."""
from pathlib import Path
import argparse,base64,csv,datetime,hashlib,io,json,os,struct,subprocess,sys,time,uuid,wave
import httpx,psutil,yaml
from dotenv import dotenv_values

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--model',choices=['qwen','rvc'],required=True)
    parser.add_argument('--medium',choices=['ssd','hdd'],required=True)
    parser.add_argument('--model-dir',type=Path)
    parser.add_argument('--samples',type=int,default=3)
    parser.add_argument('--initially-stopped',action='store_true')
    args=parser.parse_args();root=args.root.resolve();out=args.output.resolve()
    assert not out.exists(),'Refusing to replace measurement evidence'
    out.mkdir(parents=True)
    env=os.environ.copy();env.update({k:v for k,v in dotenv_values(root/'.env').items() if v is not None})
    env.update(PYTHONUTF8='1',ANIMETTA_PROFILE='production')
    env.pop('QWEN_HOST_TTS_MODEL_DIR',None);env.pop('RVC_HOST_HUBERT_MODEL_DIR',None)
    if args.model_dir:env['QWEN_HOST_TTS_MODEL_DIR' if args.model=='qwen' else 'RVC_HOST_HUBERT_MODEL_DIR']=str(args.model_dir.resolve())
    token=env['QWEN_TTS_API_KEY'];name='tts' if args.model=='qwen' else 'rvc'
    module='animetta_qwen_tts' if args.model=='qwen' else 'animetta_rvc_host'
    tts=yaml.safe_load((root/'config/host-tts.yaml').read_text());rvc=yaml.safe_load((root/'config/host-rvc.yaml').read_text())
    reference=Path(tts['runtime']['reference_audio']);source=reference.read_bytes()
    with wave.open(io.BytesIO(source),'rb') as reader:
        reader.setpos(reader.getframerate());pcm=reader.readframes(reader.getframerate()*2);buffer=io.BytesIO()
        assert len(pcm)==reader.getframerate()*2*reader.getnchannels()*reader.getsampwidth()
        with wave.open(buffer,'wb') as writer:writer.setparams(reader.getparams());writer.writeframes(pcm)
    clip=buffer.getvalue();(out/'fixed-rvc-input.wav').write_bytes(clip)
    text='你好，今天也请多关照。我们一起把这件事情做好吧。'
    meta={'schema_version':1,'model':args.model,'medium':args.medium,'samples_requested':args.samples,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256((root/'scripts/benchmark_startup.py').read_bytes()).hexdigest(),'text':text,'reference_sha256':hashlib.sha256(source).hexdigest(),'rvc_input_sha256':hashlib.sha256(clip).hexdigest(),'rvc_input_slice_seconds':[1,3],'model_dir_override':str(args.model_dir) if args.model_dir else None,'cache_contract':'Process stopped between samples. Windows and device caches are not cleared. Existing service identity hashing and warmup are included.'}
    (out/'metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    def invoke(action,label):
        run_id='m-'+uuid.uuid4().hex[:10];result=out/(label+'.json')
        command=['py','-3.13',str(root/'scripts/benchmark_startup.py'),'worker','--root',str(root),'--operation',action,'--run-id',run_id,'--phase','before' if args.medium=='ssd' else 'after','--artifacts-root',str(out/'lifecycle'),'--output',str(result)]
        started=time.perf_counter();utc=datetime.datetime.now(datetime.UTC).isoformat()
        with (out/(label+'.log')).open('xb') as log:code=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
        receipt={'command':command,'started_at':utc,'wall_seconds':time.perf_counter()-started,'exit_code':code}
        (out/(label+'-command.json')).write_text(json.dumps(receipt,indent=2))
        if code:raise RuntimeError(f'{action} failed; see {result}')
        return json.loads(result.read_text()),receipt
    def model_processes(target=None):
        found={}
        for process in psutil.process_iter(['pid','cmdline','create_time']):
            cmd=process.info['cmdline'] or []
            if '-m' not in cmd:continue
            selected=cmd[cmd.index('-m')+1] if cmd.index('-m')+1<len(cmd) else ''
            if selected not in ([target] if target else ['animetta_qwen_tts','animetta_rvc_host']):continue
            try:
                found[process.pid]=process.create_time()
                for child in process.children(recursive=True):found[child.pid]=child.create_time()
            except psutil.NoSuchProcess:continue
        return found
    def gpu_check(label):
        inventory=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,memory.used,memory.free','--format=csv'],text=True)
        raw=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,process_name','--format=csv,noheader'],text=True)
        allowed=model_processes();rows=[];unknown=[]
        ui={'explorer.exe','crossdeviceresume.exe','startmenuexperiencehost.exe','searchhost.exe','lockapp.exe','msedgewebview2.exe','textinputhost.exe','mollycloud.exe','phoneexperiencehost.exe','chatgpt.exe','msedge.exe','codex-computer-use-swift.exe','qq.exe','steamwebhelper.exe','qqex.exe','baidunetdiskunite.exe','dcv2.exe','shellexperiencehost.exe','docker desktop.exe','shellhost.exe','applicationframehost.exe','dwm.exe'}
        for row in csv.reader(raw.splitlines()):
            pid=int(row[0].strip())
            try:
                process=psutil.Process(pid);cmd=process.cmdline();name_=process.name().lower()
            except psutil.NoSuchProcess:continue
            except psutil.AccessDenied:unknown.append(pid);continue
            owned=pid in allowed or name_ in ui
            rows.append({'pid':pid,'name':name_,'command':cmd,'known':owned})
            if not owned:unknown.append(pid)
        (out/(label+'-gpu.json')).write_text(json.dumps({'inventory':inventory,'processes':rows,'unknown_pids':unknown},indent=2).replace(token,'[redacted]'))
        if unknown:raise RuntimeError(f'Unowned GPU processes: {unknown}; stopping before lifecycle mutation')
        return inventory
    samples=[]
    for i in range(1,args.samples+1):
        gpu_check(f'{i}-before-stop')
        tracked=model_processes(module)
        assert tracked or (i==1 and args.initially_stopped),'No matching target process found before stop; ownership must be checked'
        invoke(f'host-{name}-stop',f'{i}-stop')
        stop_wait_started=time.perf_counter()
        while True:
            remaining=[]
            for pid,created in tracked.items():
                try:
                    if psutil.Process(pid).create_time()==created:remaining.append(pid)
                except psutil.NoSuchProcess:pass
            current=model_processes(module)
            if not remaining and not current:break
            if time.perf_counter()-stop_wait_started>=10:
                raise RuntimeError(f'Target process remains after 10 seconds: {remaining}, {current}')
            time.sleep(0.1)
        stop_exit_wait=time.perf_counter()-stop_wait_started
        (out/(f'{i}-stop-exit-wait.json')).write_text(json.dumps({'elapsed_seconds':stop_exit_wait,'remaining_pids':remaining,'current_module_processes':current},indent=2))
        gpu=gpu_check(f'{i}-before-up')
        started_at=datetime.datetime.now(datetime.UTC).isoformat();combined_started=time.perf_counter();up,command=invoke(f'host-{name}-up',f'{i}-up')
        url='http://127.0.0.1:'+('8767' if args.model=='qwen' else '8769')
        headers={'Authorization':'Bearer '+token}
        with httpx.Client(trust_env=False,timeout=httpx.Timeout(180,connect=5)) as client:
            identity=client.get(url+'/ready',headers=headers);identity.raise_for_status();identity=identity.json();assert identity['ready']
            started=time.perf_counter();first=None;audio=bytearray()
            if args.model=='qwen':
                data={'model':tts['identity']['model'],'voice':tts['identity']['voice'],'input':text,'language':tts['client']['language'],'response_format':tts['client']['response_format'],'stream':True}
                with client.stream('POST',url+'/v1/audio/speech',headers=headers,json=data) as response:
                    response.raise_for_status();assert response.headers['content-type'].startswith('audio/pcm')
                    for chunk in response.iter_raw():
                        if chunk:
                            if first is None:first=time.perf_counter()-started
                            audio.extend(chunk)
                assert audio and len(audio)%2==0 and any(x[0]!=0 for x in struct.iter_unpack('<h',audio))
                audio_duration=len(audio)/48000;output=out/f'{i}-qwen.pcm'
            else:
                data={'model':rvc['identity']['model'],'audio_base64':base64.b64encode(clip).decode(),'f0_method':'rmvpe','f0_up_key':0,'index_rate':0.75,'filter_radius':3,'rms_mix_rate':0.5,'protect':0.5,'request_id':f'storage-{args.medium}-{i}'}
                response=client.post(url+'/v1/convert',headers=headers,json=data);response.raise_for_status();audio.extend(response.content)
                assert response.headers['x-rvc-revision']==rvc['identity']['revision']
                with wave.open(io.BytesIO(audio),'rb') as wav:
                    audio_duration=wav.getnframes()/wav.getframerate();frames=wav.readframes(wav.getnframes());assert wav.getsampwidth()==2 and frames and any(x[0]!=0 for x in struct.iter_unpack('<h',frames))
                output=out/f'{i}-rvc.wav'
            inference=time.perf_counter()-started
        combined=time.perf_counter()-combined_started;output.write_bytes(audio)
        sample={'sample':i,'started_at':started_at,'boot_time':psutil.boot_time(),'tracked_processes_exited':tracked,'stop_process_exit_wait_seconds':stop_exit_wait,'gpu_before_start':gpu,'host_up_seconds':up['elapsed_seconds'],'host_up_command_wall_seconds':command['wall_seconds'],'first_inference_seconds':inference,'first_audio_seconds':first,'combined_seconds':combined,'accounted_stage_sum_seconds':up['elapsed_seconds']+inference,'audio_bytes':len(audio),'audio_seconds':audio_duration,'audio_sha256':hashlib.sha256(audio).hexdigest(),'identity':identity,'exit_code':0}
        samples.append(sample);(out/'summary.json').write_text(json.dumps({**meta,'samples':samples},ensure_ascii=False,indent=2));print(json.dumps(sample,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
